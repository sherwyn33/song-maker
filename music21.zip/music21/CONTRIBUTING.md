`Music21` welcomes contributions such as bug reports, new features, fixes, and
documentation improvements. The
[project repository](http://www.github.com/cuthbertLab/music21) is hosted at GitHub.

Information that was formerly here is now in 
[Developer Reference](https://web.mit.edu/music21/doc/developerReference/index.html)

## Resources ##

[Module Documentation and User's Guide](https://web.mit.edu/music21/doc/index.html)

[Mailing List](https://groups.google.com/forum/#!forum/music21list)

[Code of Conduct](README.md)
