# -*- coding: utf-8 -*-
from __future__ import annotations

from music21.languageExcerpts import instrumentLookup
from music21.languageExcerpts import naturalLanguageObjects
