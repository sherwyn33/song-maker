.. _contents:

`music21` Documentation
===========================

.. toctree::
   :maxdepth: 2

   about/index

.. toctree::
   :maxdepth: 2

   usersGuide/index

.. toctree::
   :maxdepth: 1

   moduleReference/index

.. toctree::
   :maxdepth: 2

   installing/index

.. toctree::
   :maxdepth: 2

   developerReference/index

.. toctree::
   :maxdepth: 1
   
   testsAndInProgress/index